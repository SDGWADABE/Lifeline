
-- Kano Lab & Radiology Center - Supabase Schema - Vercel Single App
-- Run in Supabase SQL Editor

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- Patients
create table if not exists patients (
  id text primary key,
  name text not null,
  phone text,
  age text,
  gender text,
  created_at timestamp with time zone default now(),
  created_by text
);

-- Orders
create table if not exists orders (
  id text primary key,
  patient_id text references patients(id),
  patient_name text,
  tests text[],
  total integer,
  status text, -- AWAITING_PAYMENT, PAID, SAMPLE_COLLECTED, COMPLETED
  payment_status text, -- PENDING, PAID
  payment_method text,
  paid_at timestamp with time zone,
  created_at timestamp with time zone default now(),
  created_by text,
  timeline jsonb
);

-- Samples
create table if not exists samples (
  id text primary key,
  order_id text references orders(id),
  patient_name text,
  collected_at timestamp with time zone,
  collected_by text,
  created_at timestamp with time zone default now()
);

-- Results (lab)
create table if not exists results (
  id text primary key,
  order_id text references orders(id),
  patient_name text,
  tests jsonb,
  entered_by text,
  entered_at timestamp with time zone,
  status text,
  created_at timestamp with time zone default now()
);

-- Radiology Orders
create table if not exists radiology_orders (
  id text primary key,
  order_id text,
  patient_name text,
  modality text,
  body_part text,
  status text,
  created_at timestamp with time zone default now()
);

-- Receipts (duplicate X-printer)
create table if not exists receipts (
  id text primary key,
  order_id text references orders(id),
  patient_id text,
  patient_name text,
  tests text[],
  total integer,
  method text,
  cashier text,
  duplicate boolean default true,
  created_at timestamp with time zone default now()
);

-- Reports A4
create table if not exists reports_a4 (
  id text primary key,
  order_id text,
  type text, -- LAB, RADIOLOGY
  patient_name text,
  content jsonb,
  generated_by text,
  created_at timestamp with time zone default now()
);

-- Enable RLS and allow anon for demo (restrict in production)
alter table patients enable row level security;
alter table orders enable row level security;
alter table samples enable row level security;
alter table results enable row level security;
alter table receipts enable row level security;
alter table reports_a4 enable row level security;

create policy "Allow all for anon" on patients for all using (true) with check (true);
create policy "Allow all for anon" on orders for all using (true) with check (true);
create policy "Allow all for anon" on samples for all using (true) with check (true);
create policy "Allow all for anon" on results for all using (true) with check (true);
create policy "Allow all for anon" on receipts for all using (true) with check (true);
create policy "Allow all for anon" on reports_a4 for all using (true) with check (true);

-- For production, replace with authenticated policies:
-- create policy "Authenticated can read" on orders for select using (auth.role() = 'authenticated');
