import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey)

export const supabase = isSupabaseConfigured 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null

// Helper to sync localStorage as fallback
export const db = {
  async get(table) {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from(table).select('*').order('created_at', { ascending: false })
      if (error) { console.warn(table, error); return JSON.parse(localStorage.getItem('kano_'+table) || '[]') }
      return data || []
    }
    return JSON.parse(localStorage.getItem('kano_'+table) || '[]')
  },
  async insert(table, row) {
    const payload = { ...row, created_at: new Date().toISOString() }
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from(table).insert(payload).select().single()
      if (error) { console.warn(error); 
        const arr = JSON.parse(localStorage.getItem('kano_'+table) || '[]'); arr.unshift(payload); localStorage.setItem('kano_'+table, JSON.stringify(arr)); return payload
      }
      return data
    } else {
      const arr = JSON.parse(localStorage.getItem('kano_'+table) || '[]'); arr.unshift(payload); localStorage.setItem('kano_'+table, JSON.stringify(arr)); return payload
    }
  },
  async update(table, id, updates) {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from(table).update(updates).eq('id', id).select().single()
      if (error) { console.warn(error); }
      else return data
    }
    const arr = JSON.parse(localStorage.getItem('kano_'+table) || '[]')
    const idx = arr.findIndex(x=>x.id===id)
    if (idx>=0) { arr[idx] = {...arr[idx], ...updates}; localStorage.setItem('kano_'+table, JSON.stringify(arr)); return arr[idx] }
    return null
  }
}
