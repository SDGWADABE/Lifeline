
import React, { useState, useEffect, useMemo, useRef } from 'react'
import { supabase, isSupabaseConfigured, db } from './supabaseClient'

const TEST_CATALOG = [
  { code:'CBC', name:'Complete Blood Count', dept:'Hematology', price:5000 },
  { code:'LFT', name:'Liver Function Test', dept:'Chemistry', price:8000 },
  { code:'KFT', name:'Kidney Function Test', dept:'Chemistry', price:7000 },
  { code:'XR-CHEST', name:'X-Ray Chest PA', dept:'Radiology', price:10000 },
  { code:'US-ABD', name:'US Abdomen', dept:'Radiology', price:15000 },
]

const USERS = [
  { id:'U1', email:'super.admin@labrad.ng', pass:'Super@123', role:'SUPER_ADMIN', name:'Super Admin' },
  { id:'U2', email:'center.admin@labrad.ng', pass:'Center@123', role:'CENTER_ADMIN', name:'Center Admin' },
  { id:'U3', email:'reception@labrad.ng', pass:'Recep@123', role:'RECEPTIONIST', name:'Aisha Reception' },
  { id:'U4', email:'finance@labrad.ng', pass:'Fin@123', role:'FINANCE', name:'Musa Finance' },
  { id:'U5', email:'scientist@labrad.ng', pass:'Lab@123', role:'LAB_SCIENTIST', name:'Dr. Lab Scientist' },
  { id:'U6', email:'pathologist@labrad.ng', pass:'Path@123', role:'PATHOLOGIST', name:'Dr. Pathologist' },
  { id:'U7', email:'radiologist@labrad.ng', pass:'Rad@123', role:'RADIOLOGIST', name:'Dr. Radiologist' },
]

export default function App(){
  const [user, setUser] = useState(()=> JSON.parse(localStorage.getItem('kano_user')||'null'))
  const [loginForm, setLoginForm] = useState({email:'reception@labrad.ng', pass:'Recep@123'})
  const [patients, setPatients] = useState(()=> JSON.parse(localStorage.getItem('kano_patients')||'[]'))
  const [orders, setOrders] = useState(()=> JSON.parse(localStorage.getItem('kano_orders')||'[]'))
  const [samples, setSamples] = useState(()=> JSON.parse(localStorage.getItem('kano_samples')||'[]'))
  const [results, setResults] = useState(()=> JSON.parse(localStorage.getItem('kano_results')||'[]'))
  const [radiologyOrders, setRadiologyOrders] = useState(()=> JSON.parse(localStorage.getItem('kano_radiologyOrders')||'[]'))
  const [receipts, setReceipts] = useState(()=> JSON.parse(localStorage.getItem('kano_receipts')||'[]'))
  const [tab, setTab] = useState('dashboard')
  const [showPatientModal, setShowPatientModal] = useState(false)
  const [showOrderModal, setShowOrderModal] = useState(false)
  const [showPayModal, setShowPayModal] = useState(null)
  const [showReceiptModal, setShowReceiptModal] = useState(null)
  const [showA4Modal, setShowA4Modal] = useState(null)
  const [showResultEntry, setShowResultEntry] = useState(null)
  const [newPatient, setNewPatient] = useState({name:'', phone:'', age:'', gender:'Male'})
  const [newOrder, setNewOrder] = useState({patientId:'', tests:[]})

  useEffect(()=>{ localStorage.setItem('kano_patients', JSON.stringify(patients)) }, [patients])
  useEffect(()=>{ localStorage.setItem('kano_orders', JSON.stringify(orders)) }, [orders])
  useEffect(()=>{ localStorage.setItem('kano_samples', JSON.stringify(samples)) }, [samples])
  useEffect(()=>{ localStorage.setItem('kano_results', JSON.stringify(results)) }, [results])
  useEffect(()=>{ localStorage.setItem('kano_radiologyOrders', JSON.stringify(radiologyOrders)) }, [radiologyOrders])
  useEffect(()=>{ localStorage.setItem('kano_receipts', JSON.stringify(receipts)) }, [receipts])
  useEffect(()=>{ if(user) localStorage.setItem('kano_user', JSON.stringify(user)); else localStorage.removeItem('kano_user') }, [user])

  // Real-time sync via BroadcastChannel
  useEffect(()=>{
    const bc = new BroadcastChannel('kano_lab_sync')
    bc.onmessage = (e)=>{
      const {type, data} = e.data || {}
      if(type==='order:paid'){ setOrders(prev=> prev.map(o=> o.id===data.id ? {...o, ...data} : o)) }
      if(type==='order:created'){ setOrders(prev=> [data, ...prev]) }
      if(type==='receipt:created'){ setReceipts(prev=> [data, ...prev]) }
    }
    return ()=> bc.close()
  },[])

  const login = ()=>{
    const u = USERS.find(x=> x.email===loginForm.email && x.pass===loginForm.pass)
    if(!u) return alert('Invalid login')
    setUser(u)
  }

  const addPatient = ()=>{
    if(!newPatient.name || !newPatient.phone) return alert('Name & phone required')
    const p = { id:'LAB-KANO-'+Date.now().toString().slice(-6), name:newPatient.name, phone:newPatient.phone, age:newPatient.age, gender:newPatient.gender, createdAt:new Date().toISOString(), createdBy:user?.name }
    setPatients([p, ...patients])
    setNewPatient({name:'', phone:'', age:'', gender:'Male'})
    setShowPatientModal(false)
  }

  const createOrder = ()=>{
    if(!newOrder.patientId || newOrder.tests.length===0) return alert('Select patient and tests')
    const patient = patients.find(p=>p.id===newOrder.patientId)
    const total = newOrder.tests.reduce((s,t)=> s + (TEST_CATALOG.find(x=>x.code===t)?.price||0),0)
    const order = {
      id:'ORD-KANO-'+Date.now().toString().slice(-6),
      patientId:newOrder.patientId,
      patientName:patient?.name,
      tests:newOrder.tests,
      total,
      status:'AWAITING_PAYMENT',
      paymentStatus:'PENDING',
      paymentMethod:null,
      createdAt:new Date().toISOString(),
      createdBy:user?.name,
      assignedTo:null,
      timeline:[{at:new Date().toISOString(), by:user?.name, action:'Order created - AWAITING_PAYMENT'}]
    }
    const bc = new BroadcastChannel('kano_lab_sync')
    bc.postMessage({type:'order:created', data:order})
    setOrders([order, ...orders])
    setNewOrder({patientId:'', tests:[]})
    setShowOrderModal(false)
    // also persist to Supabase if configured
    if(isSupabaseConfigured) db.insert('orders', order)
  }

  const payOrder = (order, method='Cash')=>{
    const updated = {...order, status:'PAID', paymentStatus:'PAID', paymentMethod:method, paidAt:new Date().toISOString(), timeline:[...order.timeline, {at:new Date().toISOString(), by:user?.name, action:`Payment confirmed via ${method} - Lab & Radiology unlocked`}] }
    setOrders(prev=> prev.map(o=> o.id===order.id? updated: o))
    // receipt duplicate
    const receipt = {
      id:'INV-'+Date.now().toString().slice(-6),
      orderId:order.id,
      patientId:order.patientId,
      patientName:order.patientName,
      tests:order.tests,
      total:order.total,
      method,
      cashier:user?.name,
      createdAt:new Date().toISOString(),
      duplicate:true
    }
    setReceipts([receipt, ...receipts])
    const bc = new BroadcastChannel('kano_lab_sync')
    bc.postMessage({type:'order:paid', data:updated})
    bc.postMessage({type:'receipt:created', data:receipt})
    setShowPayModal(null)
    setShowReceiptModal(receipt)
    if(isSupabaseConfigured){ db.update('orders', order.id, {status:'PAID', paymentStatus:'PAID'}); db.insert('receipts', receipt) }
  }

  const canLab = (order)=> order.paymentStatus==='PAID'
  const addSample = (order)=>{
    if(!canLab(order)) return alert('PAYMENT REQUIRED - Cannot collect sample before payment. Go to Billing to confirm payment.')
    const s = { id:'SMP-'+Date.now().toString().slice(-5), orderId:order.id, patientName:order.patientName, collectedAt:new Date().toISOString(), collectedBy:user?.name }
    setSamples([s, ...samples])
    setOrders(prev=> prev.map(o=> o.id===order.id? {...o, status:'SAMPLE_COLLECTED', timeline:[...o.timeline, {at:new Date().toISOString(), by:user?.name, action:'Sample collected'}]}: o))
  }

  const enterResult = (order)=>{
    if(!canLab(order)) return alert('PAYMENT REQUIRED - Cannot enter lab result before payment.')
    const labTests = order.tests.filter(t=> !t.startsWith('XR') && !t.startsWith('US'))
    const result = {
      id:'RES-'+Date.now().toString().slice(-5),
      orderId:order.id,
      patientName:order.patientName,
      tests:labTests.map(code=>{
        const cat = TEST_CATALOG.find(x=>x.code===code)
        return { code, name:cat?.name, result: code==='CBC' ? 'WBC 7.2' : 'Normal', unit: code==='CBC'?'x10^9/L':'', ref:'4.0-11.0', flag:'Normal' }
      }),
      enteredBy:user?.name,
      enteredAt:new Date().toISOString(),
      status:'APPROVED'
    }
    setResults([result, ...results])
    setShowResultEntry(null)
  }

  const printThermal = (receipt)=>{
    const order = orders.find(o=> o.id===receipt.orderId)
    const w = window.open('', '_blank', 'width=380,height=700')
    if(!w) return
    const html = `
    <html><head><title>Receipt ${receipt.id}</title>
    <style>
      @page { size:80mm auto; margin:0 }
      body { width:80mm; font-family:'Courier New', monospace; font-size:11px; line-height:1.2; margin:0; padding:5mm }
      .center{ text-align:center } .bold{ font-weight:bold } .line{ border-top:1px dashed #000; margin:6px 0 } .cut{ text-align:center; margin:10px 0; border-top:2px dashed #000; padding-top:6px }
    </style></head><body>
    ${[1,2].map(copy=>`
      <div class="thermal">
        <div class="center bold">KANO LAB & RADIOLOGY CENTER</div>
        <div class="center">No 12 Zoo Road, Kano | 080XXX | KANO-01</div>
        <div class="center">${copy===1?'CUSTOMER COPY - ORIGINAL':'CENTER COPY - DUPLICATE'}</div>
        <div class="line"></div>
        <div>Receipt No: ${receipt.id}</div>
        <div>Date: ${new Date(receipt.createdAt).toLocaleString()}</div>
        <div>Cashier: ${receipt.cashier}</div>
        <div>Order: ${receipt.orderId}</div>
        <div>Patient: ${receipt.patientName} | ${receipt.patientId}</div>
        <div class="line"></div>
        ${receipt.tests.map(code=>{ const t=TEST_CATALOG.find(x=>x.code===code); return `<div>${t?.code} ${t?.name} - ₦${t?.price.toLocaleString()}</div>` }).join('')}
        <div class="line"></div>
        <div class="bold">TOTAL: ₦${receipt.total.toLocaleString()}</div>
        <div>Method: ${receipt.method} | PAID</div>
        <div class="line"></div>
        <div class="center">Payment confirmed - Lab & Radiology unlocked</div>
        <div class="center">QR: /verify/${receipt.id}</div>
        <div class="center">Thank you - Valid 30 days</div>
      </div>
      ${copy===1?'<div class="cut">--- CUT HERE --- DUPLICATE ---</div>':''}
    `).join('')}
    </body></html>`
    w.document.write(html); w.document.close(); w.focus(); setTimeout(()=>w.print(), 500)
  }

  const printA4 = (result)=>{
    const order = orders.find(o=> o.id===result.orderId)
    const w = window.open('', '_blank', 'width=900,height=1100')
    if(!w) return
    const html = `
    <html><head><title>Lab Report ${result.id}</title>
    <style>
      @page { size:A4; margin:15mm } body{ font-family:Arial; font-size:12px; margin:0; padding:15mm } .a4{ width:210mm } .header{ display:flex; justify-content:space-between; border-bottom:2px solid #000; padding-bottom:10px } table{ width:100%; border-collapse:collapse; margin-top:10px } th,td{ border:1px solid #000; padding:6px; text-align:left } .sign{ margin-top:30px; display:flex; justify-content:space-between }
    </style></head><body>
    <div class="a4">
      <div class="header"><div><b>KANO LAB & RADIOLOGY CENTER</b><br/>No 12 Zoo Road, Kano<br/>MLSCN / MDCN Licensed | KANO-01<br/>Phone: 080XXXX | Email: info@kanolab.ng</div><div>Barcode: ${order?.id}<br/>QR: /verify/${result.id}</div></div>
      <h2 style="text-align:center">LABORATORY REPORT - A4</h2>
      <div>Patient: ${result.patientName} | ID: ${order?.patientId} | Order: ${result.orderId} | Date: ${new Date(result.enteredAt).toLocaleString()} | Entered By: ${result.enteredBy}</div>
      <table><thead><tr><th>Test</th><th>Result</th><th>Unit</th><th>Reference</th><th>Flag</th></tr></thead><tbody>
      ${result.tests.map(t=>`<tr><td>${t.name}</td><td>${t.result}</td><td>${t.unit}</td><td>${t.ref}</td><td>${t.flag}</td></tr>`).join('')}
      </tbody></table>
      <div style="margin-top:15px"><b>Interpretation:</b> All parameters within normal limits unless flagged. Correlate clinically.</div>
      <div class="sign"><div>Lab Scientist: ${result.enteredBy}<br/>Signature: _____________</div><div>Pathologist: Dr. Pathologist<br/>Signature: _____________</div></div>
      <div style="margin-top:20px; font-size:10px; text-align:center">This report is electronically signed. Verify at /verify/${result.id}. Page 1 of 1. Printed on ${new Date().toLocaleString()} by ${user?.name}</div>
    </div>
    </body></html>`
    w.document.write(html); w.document.close(); w.focus(); setTimeout(()=>w.print(), 600)
  }

  if(!user){
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 to-indigo-800 p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
          <div className="text-center mb-6"><div className="w-12 h-12 bg-blue-600 rounded-xl mx-auto flex items-center justify-center text-white font-bold text-xl">LR</div><h1 className="text-2xl font-bold mt-3">Kano Lab & Radiology</h1><p className="text-sm text-slate-500">Vercel + Supabase | KANO-01 | No Branch | No 2FA</p><p className="text-xs mt-2 px-2 py-1 bg-green-50 text-green-700 rounded">{isSupabaseConfigured ? 'Supabase Connected' : 'Local Mode (Add .env to connect Supabase)'}</p></div>
          <input className="w-full border p-3 rounded-lg mb-3" placeholder="Email" value={loginForm.email} onChange={e=> setLoginForm({...loginForm, email:e.target.value})} />
          <input className="w-full border p-3 rounded-lg mb-4" type="password" placeholder="Password" value={loginForm.pass} onChange={e=> setLoginForm({...loginForm, pass:e.target.value})} />
          <button onClick={login} className="w-full bg-blue-600 text-white p-3 rounded-lg font-semibold">Login</button>
          <div className="mt-4 text-xs text-slate-500">Reception: reception@labrad.ng / Recep@123<br/>Finance: finance@labrad.ng / Fin@123</div>
        </div>
      </div>
    )
  }

  const pendingOrders = orders.filter(o=> o.paymentStatus==='PENDING')
  const paidOrders = orders.filter(o=> o.paymentStatus==='PAID')

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-white border-b sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center gap-3"><div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold">LR</div><div><div className="font-bold">Kano Lab & Radiology Center</div><div className="text-xs text-slate-500">KANO-01 | Single Center | Vercel + Supabase {isSupabaseConfigured?'🟢 Live':''}</div></div><span className="ml-3 text-[10px] bg-green-100 text-green-700 px-2 py-1 rounded-full animate-pulse">● Live - Real-time sync</span></div>
          <div className="flex items-center gap-2"><span className="text-sm">{user.name} ({user.role})</span><button onClick={()=> setUser(null)} className="text-sm border px-3 py-1 rounded">Logout</button></div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-4 grid grid-cols-12 gap-4">
        <div className="col-span-12 md:col-span-2 bg-white rounded-xl p-3 h-fit">
          {[
            {k:'dashboard', l:'Dashboard'},
            {k:'patients', l:'Patients & Billing'},
            {k:'billing', l:'Billing & Payments'},
            {k:'samples', l:'Samples'},
            {k:'results', l:'Results'},
            {k:'radiology', l:'Radiology'},
            {k:'reception-print', l:'Reception Print Center'},
            {k:'settings', l:'Settings'}
          ].map(it=> <button key={it.k} onClick={()=> setTab(it.k)} className={`w-full text-left px-3 py-2 rounded-lg text-sm mb-1 ${tab===it.k?'bg-blue-600 text-white':'hover:bg-slate-100'}`}>{it.l}</button>)}
        </div>

        <div className="col-span-12 md:col-span-10">
          {pendingOrders.length>0 && <div className="bg-red-50 border border-red-200 text-red-800 p-3 rounded-xl mb-4 text-sm"><b>PAYMENT REQUIRED</b> - Lab tests and Radiology scans locked for {pendingOrders.length} order(s). Amount due: ₦{pendingOrders.reduce((s,o)=>s+o.total,0).toLocaleString()} - Go to Billing & Payments to confirm.</div>}
          {paidOrders.length>0 && <div className="bg-green-50 border border-green-200 text-green-800 p-3 rounded-xl mb-4 text-sm"><b>PAYMENT CONFIRMED</b> - Lab & Radiology access granted for {paidOrders.length} order(s). Receipt duplicate X-printer ready.</div>}

          {tab==='dashboard' && (
            <div>
              {orders.length===0 && patients.length===0 ? (
                <div className="bg-white rounded-xl p-12 text-center"><div className="text-5xl mb-4">🏥</div><h2 className="text-xl font-bold">Welcome to Kano Lab & Radiology Center</h2><p className="text-slate-500 mt-2">No records yet. Start with Patient Registration. Payment must be completed before lab tests or scans.</p><div className="mt-6 flex justify-center gap-3"><button onClick={()=> setShowPatientModal(true)} className="bg-blue-600 text-white px-5 py-2 rounded-lg">Register Patient</button><button onClick={()=> setTab('billing')} className="border px-5 py-2 rounded-lg">Billing</button></div></div>
              ) : (
                <div className="grid grid-cols-4 gap-3">
                  {[{l:'Patients', v:patients.length},{l:'Orders', v:orders.length},{l:'Pending Payment', v:pendingOrders.length},{l:'Paid', v:paidOrders.length}].map(c=> <div key={c.l} className="bg-white p-4 rounded-xl"><div className="text-xs text-slate-500">{c.l}</div><div className="text-2xl font-bold">{c.v}</div></div>)}
                </div>
              )}
            </div>
          )}

          {tab==='patients' && (
            <div className="bg-white rounded-xl p-4">
              <div className="flex justify-between mb-4"><h2 className="font-bold">Patients & Billing (Reception)</h2><button onClick={()=> setShowPatientModal(true)} className="bg-blue-600 text-white px-3 py-1 rounded text-sm">+ Register Patient</button></div>
              <table className="w-full text-sm"><thead><tr className="text-left border-b"><th className="p-2">ID</th><th>Name</th><th>Phone</th><th>Created By</th><th>Action</th></tr></thead><tbody>{patients.map(p=> <tr key={p.id} className="border-b"><td className="p-2 mono text-xs">{p.id}</td><td>{p.name}</td><td>{p.phone}</td><td className="text-xs">{p.createdBy}</td><td><button onClick={()=>{ setNewOrder({patientId:p.id, tests:[]}); setShowOrderModal(true)}} className="text-blue-600 text-xs">Create Order</button></td></tr>)}</tbody></table>
            </div>
          )}

          {tab==='billing' && (
            <div className="bg-white rounded-xl p-4">
              <h2 className="font-bold mb-4">Billing & Payments - Payment Required Before Lab/Scan (X-Printer Duplicate Receipt)</h2>
              <table className="w-full text-sm"><thead><tr className="text-left border-b"><th className="p-2">Order</th><th>Patient</th><th>Tests</th><th>Total</th><th>Status</th><th>Action</th></tr></thead><tbody>{orders.map(o=> <tr key={o.id} className="border-b"><td className="p-2 mono text-xs">{o.id}</td><td>{o.patientName}</td><td className="text-xs">{o.tests.join(', ')}</td><td>₦{o.total.toLocaleString()}</td><td><span className={`px-2 py-1 rounded text-xs ${o.paymentStatus==='PAID'?'bg-green-100 text-green-700':'bg-red-100 text-red-700'}`}>{o.paymentStatus}</span></td><td className="flex gap-2">{o.paymentStatus==='PENDING' ? <button onClick={()=> setShowPayModal(o)} className="bg-green-600 text-white px-2 py-1 rounded text-xs">Pay Now</button> : <><button onClick={()=>{ const r=receipts.find(x=> x.orderId===o.id); if(r) setShowReceiptModal(r)}} className="border px-2 py-1 rounded text-xs">View Receipt</button><button onClick={()=>{ const r=receipts.find(x=> x.orderId===o.id); if(r) printThermal(r)}} className="bg-slate-800 text-white px-2 py-1 rounded text-xs">X-Printer Duplicate</button></>}</td></tr>)}</tbody></table>
            </div>
          )}

          {tab==='samples' && (
            <div className="bg-white rounded-xl p-4"><h2 className="font-bold mb-4">Samples - Payment Gate Enforced</h2>
            <div className="grid grid-cols-2 gap-3">{orders.map(o=> <div key={o.id} className="border p-3 rounded-lg"><div className="flex justify-between"><span className="mono text-xs">{o.id}</span><span className={`text-xs px-2 py-1 rounded ${o.paymentStatus==='PAID'?'bg-green-100':'bg-red-100'}`}>{o.paymentStatus}</span></div><div className="text-sm mt-1">{o.patientName} - {o.tests.join(', ')}</div><button onClick={()=> addSample(o)} className={`mt-2 w-full py-1 rounded text-sm ${canLab(o)?'bg-blue-600 text-white':'bg-slate-200 text-slate-500'}`}>{canLab(o)?'Collect Sample':'PAYMENT REQUIRED'}</button></div>)}</div>
            <div className="mt-4"><h3 className="font-semibold text-sm mb-2">Collected Samples</h3><table className="w-full text-sm"><tbody>{samples.map(s=> <tr key={s.id} className="border-b"><td className="p-2">{s.id}</td><td>{s.patientName}</td><td className="text-xs">{new Date(s.collectedAt).toLocaleString()} by {s.collectedBy}</td></tr>)}</tbody></table></div>
            </div>
          )}

          {tab==='results' && (
            <div className="bg-white rounded-xl p-4"><h2 className="font-bold mb-4">Results - Payment Gate + A4 Reception Print</h2>
            <div className="grid grid-cols-2 gap-3 mb-6">{orders.filter(o=> o.status!=='AWAITING_PAYMENT').map(o=> <div key={o.id} className="border p-3 rounded-lg"><div className="mono text-xs">{o.id} - {o.patientName}</div><div className="flex gap-2 mt-2"><button onClick={()=> enterResult(o)} className={`px-2 py-1 rounded text-xs ${canLab(o)?'bg-blue-600 text-white':'bg-slate-200'}`}>Enter Result</button>{!canLab(o) && <span className="text-xs text-red-600">PAYMENT REQUIRED BEFORE RESULT</span>}</div></div>)}</div>
            <h3 className="font-semibold text-sm mb-2">Lab Results (A4 in Reception)</h3>
            <table className="w-full text-sm"><thead><tr className="text-left border-b"><th>ID</th><th>Patient</th><th>Tests</th><th>By</th><th>Action</th></tr></thead><tbody>{results.map(r=> <tr key={r.id} className="border-b"><td className="p-2 mono text-xs">{r.id}</td><td>{r.patientName}</td><td className="text-xs">{r.tests.map(t=> t.code).join(', ')}</td><td className="text-xs">{r.enteredBy}</td><td className="flex gap-2"><button onClick={()=> setShowA4Modal(r)} className="border px-2 py-1 rounded text-xs">View A4</button><button onClick={()=> printA4(r)} className="bg-blue-600 text-white px-2 py-1 rounded text-xs">Print A4 Reception</button></td></tr>)}</tbody></table>
            </div>
          )}

          {tab==='reception-print' && (
            <div className="bg-white rounded-xl p-4"><h2 className="font-bold mb-4">Reception Print Center - X-Printer Receipts + A4 Results</h2>
            <div className="grid grid-cols-2 gap-6">
              <div><h3 className="font-semibold text-sm mb-2">X-Printer Duplicate Receipts (80mm)</h3><table className="w-full text-sm"><tbody>{receipts.map(rc=> <tr key={rc.id} className="border-b"><td className="p-2 mono text-xs">{rc.id}</td><td>{rc.patientName}</td><td>₦{rc.total.toLocaleString()}</td><td><button onClick={()=> printThermal(rc)} className="bg-slate-800 text-white px-2 py-1 rounded text-xs">Print Duplicate X-Printer</button></td></tr>)}</tbody></table></div>
              <div><h3 className="font-semibold text-sm mb-2">A4 Lab/Radiology Reports (Reception)</h3><table className="w-full text-sm"><tbody>{results.map(r=> <tr key={r.id} className="border-b"><td className="p-2 mono text-xs">{r.id}</td><td>{r.patientName}</td><td><button onClick={()=> printA4(r)} className="bg-blue-600 text-white px-2 py-1 rounded text-xs">Print A4</button></td></tr>)}</tbody></table></div>
            </div>
            </div>
          )}

          {tab==='radiology' && (
            <div className="bg-white rounded-xl p-4"><h2 className="font-bold">Radiology Orders - Payment Gate</h2><p className="text-sm text-slate-500 mt-2">Radiology scheduling blocked if payment PENDING. After PAID, schedule X-Ray/US. A4 radiology report printable in Reception Print Center (same A4 format).</p>
            <div className="mt-4 grid grid-cols-2 gap-3">{orders.filter(o=> o.tests.some(t=> t.includes('XR')||t.includes('US'))).map(o=> <div key={o.id} className="border p-3 rounded"><div className="text-xs mono">{o.id} {o.patientName}</div><div className={`text-xs mt-1 px-2 py-1 rounded inline-block ${o.paymentStatus==='PAID'?'bg-green-100':'bg-red-100'}`}>{o.paymentStatus}</div><div className="text-xs mt-2">{o.paymentStatus==='PENDING'?'PAYMENT REQUIRED BEFORE SCAN - Cannot schedule':'Ready for scheduling - A4 report after reporting'}</div></div>)}</div>
            </div>
          )}

          {tab==='settings' && (
            <div className="bg-white rounded-xl p-4"><h2 className="font-bold mb-2">Settings - Vercel + Supabase</h2><div className="text-sm space-y-2"><div>Supabase: {isSupabaseConfigured ? '🟢 Connected - Data syncs to Supabase' : '🔴 Local mode - Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in Vercel Env Vars'}</div><div>Center: Kano Lab & Radiology Center KANO-01 | Single Center | No Branch | No 2FA | Billing in Reception</div><div>Payment Gate: Samples, Results, Radiology scheduling, A4 printing blocked if PENDING - Strict 402</div><div>Receipt: X-printer 80mm duplicate (Customer + Center) | Results: A4 in reception</div><button onClick={()=>{ if(confirm('Clear all data?')){ localStorage.clear(); location.reload() }}} className="bg-red-600 text-white px-3 py-1 rounded text-sm">Clear All Data</button></div></div>
          )}
        </div>
      </div>

      {showPatientModal && <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"><div className="bg-white p-6 rounded-xl w-full max-w-md"><h3 className="font-bold mb-3">Register Patient</h3><input className="w-full border p-2 rounded mb-2" placeholder="Full Name" value={newPatient.name} onChange={e=> setNewPatient({...newPatient, name:e.target.value})} /><input className="w-full border p-2 rounded mb-2" placeholder="Phone" value={newPatient.phone} onChange={e=> setNewPatient({...newPatient, phone:e.target.value})} /><div className="flex gap-2 mb-3"><input className="w-1/2 border p-2 rounded" placeholder="Age" value={newPatient.age} onChange={e=> setNewPatient({...newPatient, age:e.target.value})} /><select className="w-1/2 border p-2 rounded" value={newPatient.gender} onChange={e=> setNewPatient({...newPatient, gender:e.target.value})}><option>Male</option><option>Female</option></select></div><div className="flex justify-end gap-2"><button onClick={()=> setShowPatientModal(false)} className="border px-3 py-1 rounded">Cancel</button><button onClick={addPatient} className="bg-blue-600 text-white px-3 py-1 rounded">Save</button></div></div></div>}

      {showOrderModal && <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"><div className="bg-white p-6 rounded-xl w-full max-w-md"><h3 className="font-bold mb-3">Create Order - AWAITING_PAYMENT</h3><div className="text-xs mb-2">Patient: {patients.find(p=> p.id===newOrder.patientId)?.name || 'Select below'}</div><select className="w-full border p-2 rounded mb-3" value={newOrder.patientId} onChange={e=> setNewOrder({...newOrder, patientId:e.target.value})}><option value="">Select Patient</option>{patients.map(p=> <option key={p.id} value={p.id}>{p.name} - {p.id}</option>)}</select><div className="mb-3"><div className="text-sm font-semibold mb-1">Select Tests (Payment required before lab/scan)</div>{TEST_CATALOG.map(t=> <label key={t.code} className="flex items-center gap-2 text-sm mb-1"><input type="checkbox" checked={newOrder.tests.includes(t.code)} onChange={e=>{ if(e.target.checked) setNewOrder({...newOrder, tests:[...newOrder.tests, t.code]}); else setNewOrder({...newOrder, tests:newOrder.tests.filter(x=> x!==t.code)})}} />{t.code} - {t.name} - ₦{t.price.toLocaleString()}</label>)}</div><div className="flex justify-end gap-2"><button onClick={()=> setShowOrderModal(false)} className="border px-3 py-1 rounded">Cancel</button><button onClick={createOrder} className="bg-blue-600 text-white px-3 py-1 rounded">Create (AWAITING_PAYMENT)</button></div></div></div>}

      {showPayModal && <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"><div className="bg-white p-6 rounded-xl w-full max-w-md"><h3 className="font-bold mb-3">Confirm Payment - Unlock Lab & Radiology + Receipt Duplicate X-Printer</h3><div className="text-sm mb-3">Order {showPayModal.id} - {showPayModal.patientName} - ₦{showPayModal.total.toLocaleString()}</div><div className="grid grid-cols-2 gap-2 mb-4">{['Cash','Transfer','Paystack','Flutterwave'].map(m=> <button key={m} onClick={()=> payOrder(showPayModal, m)} className="border p-3 rounded hover:bg-green-50 text-sm">{m}</button>)}</div><button onClick={()=> setShowPayModal(null)} className="w-full border py-2 rounded">Cancel</button></div></div>}

      {showReceiptModal && <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"><div className="bg-white rounded-xl w-full max-w-2xl max-h-[90vh] overflow-auto p-4"><div className="flex justify-between items-center mb-3"><h3 className="font-bold">Duplicate Receipt - X-Printer 80mm - {showReceiptModal.id}</h3><button onClick={()=> setShowReceiptModal(null)} className="border px-2 py-1 rounded text-sm">Close</button></div><div className="grid grid-cols-2 gap-4">
        {[1,2].map(copy=> <div key={copy} className="thermal border p-3 bg-white"><div className="center bold">KANO LAB & RADIOLOGY</div><div className="center text-[10px]">No 12 Zoo Road, Kano | KANO-01</div><div className="center bold text-xs mt-1">{copy===1?'CUSTOMER COPY - ORIGINAL':'CENTER COPY - DUPLICATE'}</div><div className="line"></div><div>Receipt: {showReceiptModal.id}</div><div>Date: {new Date(showReceiptModal.createdAt).toLocaleString()}</div><div>Cashier: {showReceiptModal.cashier}</div><div>Order: {showReceiptModal.orderId}</div><div>Patient: {showReceiptModal.patientName}</div><div className="line"></div>{showReceiptModal.tests.map(code=>{ const t=TEST_CATALOG.find(x=>x.code===code); return <div key={code}>{t?.code} {t?.name} ₦{t?.price.toLocaleString()}</div>})}<div className="line"></div><div className="bold">TOTAL: ₦{showReceiptModal.total.toLocaleString()} PAID via {showReceiptModal.method}</div><div className="center mt-2">QR: /verify/{showReceiptModal.id}<br/>Payment confirmed - Lab & Radiology unlocked</div></div>)}
      </div><div className="mt-4 flex gap-2"><button onClick={()=> printThermal(showReceiptModal)} className="bg-slate-800 text-white px-4 py-2 rounded text-sm">Print Duplicate X-Printer (80mm)</button><button onClick={()=> setShowReceiptModal(null)} className="border px-4 py-2 rounded text-sm">Close</button></div></div></div>}

      {showA4Modal && <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"><div className="bg-white rounded-xl w-full max-w-4xl max-h-[90vh] overflow-auto p-4"><div className="flex justify-between mb-3"><h3 className="font-bold">A4 Lab Report - Reception - {showA4Modal.id}</h3><div className="flex gap-2"><button onClick={()=> printA4(showA4Modal)} className="bg-blue-600 text-white px-3 py-1 rounded text-sm">Print A4 Reception</button><button onClick={()=> setShowA4Modal(null)} className="border px-3 py-1 rounded text-sm">Close</button></div></div><div className="a4 border"><div className="flex justify-between border-b-2 border-black pb-2"><div><b>KANO LAB & RADIOLOGY CENTER</b><br/>No 12 Zoo Road, Kano | MLSCN Licensed | KANO-01</div><div>Barcode: {showA4Modal.orderId}<br/>QR: /verify/{showA4Modal.id}</div></div><h2 className="text-center font-bold mt-3">LABORATORY REPORT - A4</h2><div className="mt-2 text-xs">Patient: {showA4Modal.patientName} | Order: {showA4Modal.orderId} | Date: {new Date(showA4Modal.enteredAt).toLocaleString()} | By: {showA4Modal.enteredBy}</div><table className="w-full border-collapse mt-3"><thead><tr><th className="border p-1 text-left">Test</th><th className="border p-1">Result</th><th className="border p-1">Unit</th><th className="border p-1">Reference</th><th className="border p-1">Flag</th></tr></thead><tbody>{showA4Modal.tests.map((t,i)=> <tr key={i}><td className="border p-1">{t.name}</td><td className="border p-1">{t.result}</td><td className="border p-1">{t.unit}</td><td className="border p-1">{t.ref}</td><td className="border p-1">{t.flag}</td></tr>)}</tbody></table><div className="mt-6 flex justify-between"><div>Lab Scientist: {showA4Modal.enteredBy}<br/>Signature: __________</div><div>Pathologist: Dr. Pathologist<br/>Signature: __________</div></div><div className="text-[10px] text-center mt-6">Electronically signed. Verify at /verify/{showA4Modal.id}. Printed on {new Date().toLocaleString()} by {user?.name}</div></div></div></div>}
    </div>
  )
}
